// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(a=>{
  a.addEventListener('click',e=>{
    e.preventDefault();
    const t=document.querySelector(a.getAttribute('href'));
    if(t) t.scrollIntoView({behavior:'smooth'});
  });
});

// Load projects
fetch('http://localhost:5000/api/projects')
  .then(r=>r.json())
  .then(rows=>{
    const list=document.getElementById('projectList');
    list.innerHTML = rows.map(p=>`<div class="card"><h3>${p.title}</h3><p>${p.description||''}</p></div>`).join('');
  })
  .catch(console.error);

// Load achievements
fetch('http://localhost:5000/api/achievements')
  .then(r=>r.json())
  .then(rows=>{
    const ul=document.getElementById('achievementList');
    ul.innerHTML = rows.map(a=>`<li>${a.title} (${a.year})</li>`).join('');
  })
  .catch(console.error);

// Contact form
document.getElementById('contactForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const message = document.getElementById('message').value.trim();
  const res = await fetch('http://localhost:5000/api/contact', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({name,email,message})
  });
  const data = await res.json();
  document.getElementById('responseMsg').textContent = data.msg || (data.success ? 'Message sent!' : 'Error');
  if(data.success) e.target.reset();
});
