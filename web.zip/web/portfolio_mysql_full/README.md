# Portfolio Website (Frontend HTML/CSS/JS + Backend Node.js + MySQL)

## Structure
- `frontend/` — static website (open index.html in browser)
- `backend/` — Express REST API
- `sql/portfolio.sql` — MySQL schema + sample data
- `package.json` — Node dependencies and start script

## Prerequisites
- Node.js (v16+)
- MySQL Server (Workbench optional)

## Setup
1) Install Node packages (run in project root):
```bash
npm install
```
2) Create database & tables:
- Open MySQL Workbench (or terminal) and run:
```sql
SOURCE sql/portfolio.sql;
```
3) Configure DB password:
- Edit `backend/db.js` and set `user`, `password` if needed.

4) Start backend server:
```bash
npm start
```
Server runs at: `http://localhost:5000`

5) Open frontend:
- Open `frontend/index.html` in your browser.
- The page will fetch:
  - `GET /api/projects`
  - `GET /api/achievements`
  - `POST /api/contact`
## Notes
- To view saved messages, check MySQL table `contact`.
- You can add more projects/achievements via MySQL inserts.
