CREATE DATABASE IF NOT EXISTS portfolio_db;
USE portfolio_db;

CREATE TABLE IF NOT EXISTS projects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  description TEXT
);

CREATE TABLE IF NOT EXISTS achievements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  year INT
);

CREATE TABLE IF NOT EXISTS contact (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO projects (title, description) VALUES
('Portfolio Website', 'A personal portfolio built with HTML, CSS, JavaScript, and Node.js.'),
('E-Commerce App', 'Online store with cart and checkout system.');

INSERT INTO achievements (title, year) VALUES
('Secured a Full Stack Web Development', 2025),
('Achived 83.80% in SSC and 78.94% in Diploma', 2023),
('Full Stack Certification', 2025);
