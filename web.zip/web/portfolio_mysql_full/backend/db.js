const mysql = require('mysql2');
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',         // change if needed
  password: 'mohini@04', // change to your password
  database: 'portfolio_db'
});
db.connect(err => {
  if (err) {
    console.error('MySQL Connection Error:', err);
    process.exit(1);
  }
  console.log('✅ Connected to MySQL Database');
});
module.exports = db;
