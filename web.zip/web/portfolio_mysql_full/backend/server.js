const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());

// Routes
app.get('/api/projects', (req, res) => {
  db.query('SELECT id, title, description FROM projects ORDER BY id DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(rows);
  });
});

app.get('/api/achievements', (req, res) => {
  db.query('SELECT id, title, year FROM achievements ORDER BY year DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(rows);
  });
});

app.post('/api/contact', (req, res) => {
  const { name, email, message } = req.body || {};
  if(!name || !email || !message) return res.status(400).json({ error: 'All fields required' });
  db.query('INSERT INTO contact (name, email, message) VALUES (?, ?, ?)', [name, email, message], (err) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json({ success: true, msg: 'Message saved successfully!' });
  });
});

app.listen(PORT, () => console.log(`🚀 Server running on http://localhost:${PORT}`));
